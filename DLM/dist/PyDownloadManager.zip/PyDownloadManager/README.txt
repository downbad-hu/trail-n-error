PyDownload Manager
=================

This application requires Python 3.6+ and the following packages:
- PyQt5
- requests

To install the required packages, run:
pip install -r requirements.txt

To start the application:
1. Double-click on PyDownloadManager.bat

If you encounter any issues, please refer to TROUBLESHOOTING.md
